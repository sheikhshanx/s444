
// s444 - Game Website with Withdraw Form, Sound FX, and Player Balance

import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function HomePage() {
  const [spinResult, setSpinResult] = useState(null);
  const [diceResult, setDiceResult] = useState(null);
  const [cardResult, setCardResult] = useState(null);
  const [activeMembers, setActiveMembers] = useState(0);
  const [balance, setBalance] = useState(1000);
  const [withdrawName, setWithdrawName] = useState("");
  const [withdrawNumber, setWithdrawNumber] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawMessage, setWithdrawMessage] = useState("");

  const playSound = (type) => {
    const audio = new Audio(`/sounds/${type}.mp3`);
    audio.play();
  };

  const handleSpin = () => {
    const results = ["Win", "Lose", "Try Again"];
    const result = results[Math.floor(Math.random() * results.length)];
    setSpinResult(result);
    playSound(result === "Win" ? "win" : "lose");
    if (result === "Win") setBalance((prev) => prev + 100);
    else if (result === "Lose") setBalance((prev) => Math.max(prev - 50, 0));
  };

  const handleDice = () => {
    const result = Math.floor(Math.random() * 6) + 1;
    setDiceResult(result);
    playSound("click");
    setBalance((prev) => prev + result * 10);
  };

  const handleCardFlip = () => {
    const cards = ["Ace", "King", "Queen", "Jack", "10", "9"];
    const result = cards[Math.floor(Math.random() * cards.length)];
    setCardResult(result);
    playSound("flip");
    if (result === "Ace") setBalance((prev) => prev + 200);
    else setBalance((prev) => prev + 50);
  };

  const handleWithdraw = () => {
    const amount = parseInt(withdrawAmount);
    if (!withdrawName || !withdrawNumber || !amount || amount > balance) {
      setWithdrawMessage("❌ Invalid input or insufficient balance");
      playSound("error");
      return;
    }
    setBalance((prev) => prev - amount);
    setWithdrawMessage("✅ Withdraw request submitted successfully!");
    playSound("success");
    setWithdrawName("");
    setWithdrawNumber("");
    setWithdrawAmount("");
  };

  useEffect(() => {
    const generateRandomMembers = () => {
      const min = 6000;
      const max = 7000;
      return Math.floor(Math.random() * (max - min + 1)) + min;
    };
    setActiveMembers(generateRandomMembers());
    const interval = setInterval(() => {
      setActiveMembers(generateRandomMembers());
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <header className="text-center text-4xl font-bold mb-2 text-yellow-400">s444</header>
      <p className="text-center text-sm text-gray-400 mb-4">📈 {activeMembers} Active Members Online</p>
      <p className="text-center text-lg text-green-400 font-semibold mb-6">💰 Balance: ৳{balance}</p>

      <div className="max-w-md mx-auto bg-gray-800 p-6 rounded-2xl shadow-lg mb-6">
        <h2 className="text-2xl mb-4">Login / Register</h2>
        <input className="w-full mb-3 p-2 rounded bg-gray-700 text-white" placeholder="Username" />
        <input className="w-full mb-3 p-2 rounded bg-gray-700 text-white" placeholder="Password" type="password" />
        <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-black">Login</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gray-800">
          <CardContent className="p-6 text-center">
            <h3 className="text-xl mb-2">Lucky Spin</h3>
            <Button onClick={handleSpin} className="bg-yellow-500 hover:bg-yellow-600 text-black mb-2">Spin</Button>
            {spinResult && <p>Result: <span className="text-green-400 font-semibold">{spinResult}</span></p>}
          </CardContent>
        </Card>

        <Card className="bg-gray-800">
          <CardContent className="p-6 text-center">
            <h3 className="text-xl mb-2">Dice Roll</h3>
            <Button onClick={handleDice} className="bg-yellow-500 hover:bg-yellow-600 text-black mb-2">Roll</Button>
            {diceResult && <p>Result: <span className="text-green-400 font-semibold">{diceResult}</span></p>}
          </CardContent>
        </Card>

        <Card className="bg-gray-800">
          <CardContent className="p-6 text-center">
            <h3 className="text-xl mb-2">Card Flip</h3>
            <Button onClick={handleCardFlip} className="bg-yellow-500 hover:bg-yellow-600 text-black mb-2">Flip</Button>
            {cardResult && <p>Result: <span className="text-green-400 font-semibold">{cardResult}</span></p>}
          </CardContent>
        </Card>
      </div>

      <div className="mt-10 max-w-lg mx-auto bg-gray-800 p-6 rounded-2xl">
        <h2 className="text-2xl mb-4 text-yellow-300">Deposit Options</h2>
        <ul className="space-y-2">
          <li>Bkash: <span className="text-green-400 font-semibold">01753534428</span></li>
          <li>Nagad: <span className="text-green-400 font-semibold">01627690821</span></li>
        </ul>
      </div>

      <div className="mt-10 max-w-lg mx-auto bg-gray-800 p-6 rounded-2xl">
        <h2 className="text-2xl mb-4 text-yellow-300">Withdraw Balance</h2>
        <input value={withdrawName} onChange={(e) => setWithdrawName(e.target.value)} className="w-full mb-3 p-2 rounded bg-gray-700 text-white" placeholder="Your Name" />
        <input value={withdrawNumber} onChange={(e) => setWithdrawNumber(e.target.value)} className="w-full mb-3 p-2 rounded bg-gray-700 text-white" placeholder="Bkash/Nagad Number" />
        <input value={withdrawAmount} onChange={(e) => setWithdrawAmount(e.target.value)} className="w-full mb-3 p-2 rounded bg-gray-700 text-white" placeholder="Withdraw Amount (৳)" type="number" />
        <Button onClick={handleWithdraw} className="w-full bg-yellow-500 hover:bg-yellow-600 text-black">Submit Request</Button>
        {withdrawMessage && <p className="text-center mt-3 text-green-400 font-semibold">{withdrawMessage}</p>}
      </div>

      <div className="mt-10 max-w-2xl mx-auto bg-gray-800 p-6 rounded-2xl">
        <h2 className="text-2xl mb-4 text-yellow-300">User Reviews</h2>
        <ul className="space-y-4">
          <li className="bg-gray-700 p-4 rounded-lg">
            <p className="text-green-300 font-semibold">“I hate won 15k on S444 – best website!”</p>
            <span className="text-sm text-gray-400">— Rafsan, Dhaka</span>
          </li>
          <li className="bg-gray-700 p-4 rounded-lg">
            <p className="text-green-300 font-semibold">“তিন দিনেই ৮০০০ টাকা জিতেছি! অসাধারণ এক্সপেরিয়েন্স।”</p>
            <span className="text-sm text-gray-400">— Hasan, Chattogram</span>
          </li>
          <li className="bg-gray-700 p-4 rounded-lg">
            <p className="text-green-300 font-semibold">“S444 legit. Withdraw instantly পেলাম Bkash এ।”</p>
            <span className="text-sm text-gray-400">— Jamil, Sylhet</span>
          </li>
        </ul>
      </div>
    </div>
  );
}
